import './main.css';
import imgB from './svgs/alert.svg';

window.document.getElementById('app').innerHTML = `
<img src="${imgB}"/>
`;
